"""Performance Optimizer Agent - Detects performance issues"""

import ast
import re
import logging
from typing import Dict, List, Optional

from ..core.agent import BaseAgent, AnalysisResult, CodeIssue, SeverityLevel, AgentType

logger = logging.getLogger(__name__)


class PerformanceOptimizerAgent(BaseAgent):
    """Detects performance bottlenecks and suggests optimizations"""

    def __init__(self):
        super().__init__("PerformanceOptimizer", AgentType.PERFORMANCE_OPTIMIZER)

    def _initialize(self) -> None:
        logger.info("PerformanceOptimizer Agent initialized")

    def get_priority(self) -> int:
        return 3

    async def analyze(self, file_path: str, code: str, context: Optional[Dict] = None) -> AnalysisResult:
        result = AnalysisResult(agent_type=self.agent_type)
        result.reasoning_chain.append("Step 1: Analyze algorithmic complexity")
        result.reasoning_chain.append("Step 2: Detect inefficient patterns")
        result.reasoning_chain.append("Step 3: Check memory usage patterns")
        result.reasoning_chain.append("Step 4: Identify optimization opportunities")

        lines = code.split('\n')

        self._check_inefficient_loops(code, lines, file_path, result)
        self._check_string_concatenation(code, lines, file_path, result)
        self._check_list_operations(code, lines, file_path, result)
        self._check_imports(code, file_path, result)
        self._check_global_variables(code, file_path, result)

        result.summary = f"Performance analysis complete: {len(result.issues)} issues found"
        return result

    def _check_inefficient_loops(self, code: str, lines: List, file_path: str, result: AnalysisResult) -> None:
        for i, line in enumerate(lines):
            if re.search(r'for\s+\w+\s+in\s+range\(len\(', line):
                result.add_issue(CodeIssue(
                    issue_id="PERF_001",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.MEDIUM,
                    title="Unnecessary Index Iteration",
                    description="Using range(len()) is often unnecessary",
                    file_path=file_path,
                    line_number=i + 1,
                    code_snippet=line.strip(),
                    suggestion="Use enumerate() or iterate directly over the collection"
                ))

    def _check_string_concatenation(self, code: str, lines: List, file_path: str, result: AnalysisResult) -> None:
        concat_count = 0
        for line in lines:
            if '+' in line and ('"' in line or "'" in line):
                concat_count += 1
        
        if concat_count > 5:
            result.add_issue(CodeIssue(
                issue_id="PERF_002",
                agent_type=self.agent_type,
                severity=SeverityLevel.LOW,
                title="Excessive String Concatenation",
                description=f"Found {concat_count} string concatenations in code",
                file_path=file_path,
                line_number=0,
                suggestion="Use f-strings or str.join() for better performance"
            ))

    def _check_list_operations(self, code: str, lines: List, file_path: str, result: AnalysisResult) -> None:
        tree = ast.parse(code)
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Attribute):
                    if node.func.attr == 'append' and self._in_loop(node, tree):
                        result.add_issue(CodeIssue(
                            issue_id="PERF_003",
                            agent_type=self.agent_type,
                            severity=SeverityLevel.LOW,
                            title="Consider List Comprehension",
                            description="Using append() in loop instead of list comprehension",
                            file_path=file_path,
                            line_number=node.lineno,
                            suggestion="Replace with list comprehension for better performance"
                        ))

    def _in_loop(self, node: ast.AST, tree: ast.AST) -> bool:
        for parent in ast.walk(tree):
            if isinstance(parent, (ast.For, ast.While)):
                for child in ast.walk(parent):
                    if child is node:
                        return True
        return False

    def _check_imports(self, code: str, file_path: str, result: AnalysisResult) -> None:
        if re.search(r'^import\s+\w+', code, re.MULTILINE):
            if 'from' not in code:
                result.add_issue(CodeIssue(
                    issue_id="PERF_004",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.INFO,
                    title="Consider Selective Imports",
                    description="Importing entire module may impact startup time",
                    file_path=file_path,
                    line_number=0,
                    suggestion="Use 'from module import specific_item' for faster imports"
                ))

    def _check_global_variables(self, code: str, file_path: str, result: AnalysisResult) -> None:
        tree = ast.parse(code)
        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        result.add_issue(CodeIssue(
                            issue_id="PERF_005",
                            agent_type=self.agent_type,
                            severity=SeverityLevel.INFO,
                            title="Global Constant Detected",
                            description=f"Global constant '{target.id}' detected",
                            file_path=file_path,
                            line_number=node.lineno,
                            suggestion="Consider using a configuration class or module"
                        ))
