"""Multi-agent orchestrator with long-chain reasoning"""

import asyncio
import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field

from ..core.agent import (
    BaseAgent, AnalysisResult, CodeIssue, SeverityLevel, AgentType
)

logger = logging.getLogger(__name__)


@dataclass
class ReasoningStep:
    """A single step in the reasoning chain"""
    step_number: int
    agent_name: str
    action: str
    findings: List[str]
    decisions: List[str]
    next_steps: List[str]

    def to_dict(self) -> Dict:
        return {
            "step": self.step_number,
            "agent": self.agent_name,
            "action": self.action,
            "findings": self.findings,
            "decisions": self.decisions,
            "next_steps": self.next_steps
        }


@dataclass
class OrchestrationResult:
    """Complete orchestration result"""
    file_path: str
    results: List[AnalysisResult] = field(default_factory=list)
    reasoning_chain: List[ReasoningStep] = field(default_factory=list)
    total_issues: int = 0
    execution_time: float = 0.0
    recommendations: List[str] = field(default_factory=list)

    def add_result(self, result: AnalysisResult) -> None:
        self.results.append(result)
        self.total_issues += len(result.issues)

    def get_summary(self) -> str:
        critical = sum(1 for r in self.results for i in r.issues 
                      if i.severity == SeverityLevel.CRITICAL)
        high = sum(1 for r in self.results for i in r.issues 
                  if i.severity == SeverityLevel.HIGH)
        medium = sum(1 for r in self.results for i in r.issues 
                    if i.severity == SeverityLevel.MEDIUM)
        
        return (f"Analysis complete: {critical} critical, {high} high, "
                f"{medium} medium issues found in {len(self.results)} agents")

    def to_report(self) -> str:
        report = []
        report.append("=" * 80)
        report.append("AI CODE REVIEW REPORT")
        report.append("=" * 80)
        report.append(f"\nFile: {self.file_path}")
        report.append(f"Total Issues: {self.total_issues}")
        report.append(f"Agents Used: {len(self.results)}")
        report.append(f"Execution Time: {self.execution_time:.2f}s")
        report.append("\n")

        report.append("-" * 80)
        report.append("REASONING CHAIN")
        report.append("-" * 80)
        for step in self.reasoning_chain:
            report.append(f"\nStep {step.step_number}: {step.agent_name}")
            report.append(f"  Action: {step.action}")
            report.append(f"  Findings: {', '.join(step.findings)}")
            report.append(f"  Decisions: {', '.join(step.decisions)}")
        report.append("\n")

        report.append("-" * 80)
        report.append("DETAILED ISSUES")
        report.append("-" * 80)
        for result in self.results:
            report.append(f"\n[{result.agent_type.value.upper()}]")
            for issue in sorted(result.issues, key=lambda x: x.severity.value):
                report.append(f"  [{issue.severity.value.upper()}] {issue.title}")
                report.append(f"    Line {issue.line_number}: {issue.description}")
                if issue.suggestion:
                    report.append(f"    Suggestion: {issue.suggestion}")
        report.append("\n")

        if self.recommendations:
            report.append("-" * 80)
            report.append("RECOMMENDATIONS")
            report.append("-" * 80)
            for i, rec in enumerate(self.recommendations, 1):
                report.append(f"{i}. {rec}")
            report.append("\n")

        report.append("=" * 80)
        return "\n".join(report)


class AgentOrchestrator:
    """Orchestrates multiple agents with long-chain reasoning"""

    def __init__(self, agents: List[BaseAgent]):
        self.agents = sorted(agents, key=lambda a: a.get_priority())
        self.reasoning_chain: List[ReasoningStep] = []
        self.current_context: Dict = {}

    async def orchestrate(self, file_path: str, code: str) -> OrchestrationResult:
        """Execute multi-agent analysis with reasoning chain"""
        import time
        start_time = time.time()
        
        result = OrchestrationResult(file_path=file_path)
        self.reasoning_chain = []
        self.current_context = {"file_path": file_path}

        logger.info(f"Starting orchestration for {file_path}")

        step_number = 1
        for agent in self.agents:
            if not agent.can_handle(file_path):
                logger.debug(f"Agent {agent.name} cannot handle {file_path}")
                continue

            logger.info(f"Executing agent: {agent.name}")
            
            reasoning_step = await self._execute_agent_with_reasoning(
                agent, file_path, code, step_number
            )
            self.reasoning_chain.append(reasoning_step)

            analysis_result = await agent.analyze(
                file_path, code, self.current_context
            )
            result.add_result(analysis_result)

            self._update_context_from_result(analysis_result)
            step_number += 1

        result.reasoning_chain = self.reasoning_chain
        result.execution_time = time.time() - start_time
        result.recommendations = self._generate_recommendations(result)

        logger.info(f"Orchestration complete: {result.total_issues} issues found")
        return result

    async def _execute_agent_with_reasoning(
        self, agent: BaseAgent, file_path: str, code: str, step_number: int
    ) -> ReasoningStep:
        """Execute agent with explicit reasoning documentation"""
        findings = []
        decisions = []
        next_steps = []

        findings.append(f"Analyzing {file_path} with {agent.name}")
        
        if self.current_context.get("previous_issues"):
            findings.append(f"Considering {len(self.current_context['previous_issues'])} previous issues")

        decisions.append(f"Executing {agent.agent_type.value} analysis")
        
        if agent.agent_type == AgentType.SECURITY_AUDIT:
            decisions.append("Prioritizing security vulnerabilities")
            next_steps.append("Generate security fix recommendations")
        elif agent.agent_type == AgentType.PERFORMANCE_OPTIMIZER:
            decisions.append("Analyzing computational complexity")
            next_steps.append("Suggest performance improvements")
        elif agent.agent_type == AgentType.STYLE_CHECKER:
            decisions.append("Checking code style conventions")
            next_steps.append("Generate style corrections")

        return ReasoningStep(
            step_number=step_number,
            agent_name=agent.name,
            action=f"Execute {agent.agent_type.value} analysis",
            findings=findings,
            decisions=decisions,
            next_steps=next_steps
        )

    def _update_context_from_result(self, result: AnalysisResult) -> None:
        """Update shared context with agent results for next agents"""
        if "previous_issues" not in self.current_context:
            self.current_context["previous_issues"] = []
        
        self.current_context["previous_issues"].extend([
            i.to_dict() for i in result.issues
        ])
        
        self.current_context.update(result.metrics)

    def _generate_recommendations(self, result: OrchestrationResult) -> List[str]:
        """Generate high-level recommendations based on all results"""
        recommendations = []
        
        critical_count = sum(
            1 for r in result.results 
            for i in r.issues 
            if i.severity == SeverityLevel.CRITICAL
        )
        
        if critical_count > 0:
            recommendations.append(
                f"URGENT: Address {critical_count} critical issues before deployment"
            )

        security_issues = [
            i for r in result.results 
            for i in r.issues 
            if r.agent_type == AgentType.SECURITY_AUDIT
        ]
        if security_issues:
            recommendations.append(
                "Review and fix all security vulnerabilities"
            )

        performance_metrics = {
            k: v for r in result.results 
            for k, v in r.metrics.items() 
            if "complexity" in k.lower() or "performance" in k.lower()
        }
        if performance_metrics:
            recommendations.append(
                "Optimize code complexity and performance bottlenecks"
            )

        if not recommendations:
            recommendations.append("Code quality is good. Continue following best practices.")

        return recommendations
