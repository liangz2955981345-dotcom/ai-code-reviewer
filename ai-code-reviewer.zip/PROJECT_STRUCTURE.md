ai-code-reviewer/
├── src/
│   ├── __init__.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── agent.py
│   │   └── orchestrator.py
│   └── agents/
│       ├── __init__.py
│       ├── code_parser.py
│       ├── security_audit.py
│       ├── performance_optimizer.py
│       └── style_checker.py
├── examples/
│   └── sample_code.py
├── tests/
│   └── test_agents.py
├── main.py
├── config.json
├── requirements.txt
├── run.bat
└── README.md
