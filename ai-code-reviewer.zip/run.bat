@echo off
echo ========================================
echo AI Code Reviewer - Quick Start
echo ========================================
echo.

echo Running demo analysis...
echo.
python main.py demo

echo.
echo ========================================
echo Running tests...
echo.
python tests\test_agents.py

echo.
echo ========================================
echo Done!
pause
