# AI Code Reviewer - Multi-Agent 代码审查与优化平台

## 项目简介

AI驱动的多Agent协作代码审查平台，通过4个专业Agent协同工作，提供从代码结构分析、安全审计、性能优化到代码风格检查的全方位代码质量评估。

## 核心特性

### 1. 多Agent协作架构
- **CodeParser Agent**: AST解析与代码结构分析
- **SecurityAudit Agent**: 10+种安全漏洞模式检测
- **PerformanceOptimizer Agent**: 算法复杂度与性能瓶颈分析
- **StyleChecker Agent**: PEP 8规范与代码风格检查

### 2. 长链推理能力
每个Agent执行时都记录完整的推理链条：
```
Step 1: 加载分析模式 → Step 2: 扫描代码 → Step 3: 上下文分析 → Step 4: 优先级排序
```

### 3. 智能决策
- 问题严重性自动分级（CRITICAL/HIGH/MEDIUM/LOW/INFO）
- 跨Agent上下文共享
- 自动化修复建议生成

## 快速开始

### 运行演示
```bash
python main.py demo
```

### 分析代码文件
```bash
python main.py analyze your_code.py
```

### 分析整个目录
```bash
python main.py analyze ./src
```

### 导出JSON报告
```bash
python main.py analyze your_code.py --format json
```

### 运行测试
```bash
python tests/test_agents.py
```

## 输出示例

```
================================================================================
AI CODE REVIEW REPORT
================================================================================

File: examples/sample_code.py
Total Issues: 15
Agents Used: 4
Execution Time: 0.125s

--------------------------------------------------------------------------------
REASONING CHAIN
--------------------------------------------------------------------------------

Step 1: CodeParser
  Action: Parse code into AST
  Findings: Successfully parsed AST
  Decisions: Analyze code structure

Step 2: SecurityAudit
  Action: Scan for vulnerabilities
  Findings: Found 3 critical vulnerabilities
  Decisions: Prioritize security issues

...

--------------------------------------------------------------------------------
DETAILED ISSUES
--------------------------------------------------------------------------------

[SECURITY_AUDIT]
  [CRITICAL] Command Injection Risk
    Line 25: os.system() is vulnerable to command injection
    Suggestion: Use subprocess.run() with shell=False

[PERFORMANCE_OPTIMIZER]
  [MEDIUM] Unnecessary Index Iteration
    Line 8: Using range(len()) is often unnecessary
    Suggestion: Use enumerate() or iterate directly

================================================================================
```

## 项目结构

```
ai-code-reviewer/
├── src/
│   ├── core/
│   │   ├── agent.py           # 核心Agent基类
│   │   └── orchestrator.py    # 多Agent编排器
│   └── agents/
│       ├── code_parser.py     # 代码解析Agent
│       ├── security_audit.py  # 安全审计Agent
│       ├── performance_optimizer.py  # 性能优化Agent
│       └── style_checker.py   # 风格检查Agent
├── examples/
│   └── sample_code.py         # 示例代码
├── tests/
│   └── test_agents.py         # 单元测试
├── main.py                    # CLI入口
├── config.json                # 配置文件
└── run.bat                    # Windows快速启动
```

## 技术架构

### Agent执行流程
```
CodeParser → SecurityAudit → PerformanceOptimizer → StyleChecker
     ↓            ↓                ↓                    ↓
  AST解析    漏洞扫描         性能分析              风格检查
     ↓            ↓                ↓                    ↓
     └────────────┴────────────────┴────────────────────┘
                          ↓
                   Orchestration Result
                          ↓
                   综合建议生成
```

### 推理链示例
```json
{
  "step": 1,
  "agent": "SecurityAudit",
  "action": "Execute security_audit analysis",
  "findings": ["Analyzing code with 10 vulnerability patterns"],
  "decisions": ["Prioritizing security vulnerabilities"],
  "next_steps": ["Generate security fix recommendations"]
}
```

## 可扩展性

添加新Agent只需：
1. 继承`BaseAgent`类
2. 实现`analyze()`方法
3. 在orchestrator中注册

## License

MIT License
