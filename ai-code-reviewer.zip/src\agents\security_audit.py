"""Security Audit Agent - Detects security vulnerabilities"""

import re
import logging
from typing import Dict, Optional

from ..core.agent import BaseAgent, AnalysisResult, CodeIssue, SeverityLevel, AgentType

logger = logging.getLogger(__name__)


class SecurityAuditAgent(BaseAgent):
    """Detects security vulnerabilities in code"""

    VULNERABILITY_PATTERNS = [
        {
            "pattern": r'eval\s*\(',
            "issue_id": "SEC_001",
            "severity": SeverityLevel.CRITICAL,
            "title": "Use of eval()",
            "description": "eval() can execute arbitrary code",
            "suggestion": "Use ast.literal_eval() for safe evaluation or avoid dynamic code execution"
        },
        {
            "pattern": r'exec\s*\(',
            "issue_id": "SEC_002",
            "severity": SeverityLevel.CRITICAL,
            "title": "Use of exec()",
            "description": "exec() can execute arbitrary code",
            "suggestion": "Remove exec() or use safer alternatives"
        },
        {
            "pattern": r'os\.system\s*\(',
            "issue_id": "SEC_003",
            "severity": SeverityLevel.CRITICAL,
            "title": "Command Injection Risk",
            "description": "os.system() is vulnerable to command injection",
            "suggestion": "Use subprocess.run() with shell=False and list arguments"
        },
        {
            "pattern": r'subprocess\.\w+\(.*shell\s*=\s*True',
            "issue_id": "SEC_004",
            "severity": SeverityLevel.CRITICAL,
            "title": "Shell Injection Risk",
            "description": "Using shell=True in subprocess can lead to shell injection",
            "suggestion": "Use shell=False and pass arguments as a list"
        },
        {
            "pattern": r'__import__\s*\(',
            "issue_id": "SEC_005",
            "severity": SeverityLevel.HIGH,
            "title": "Dynamic Import",
            "description": "Dynamic imports can load malicious modules",
            "suggestion": "Use importlib with validated module names"
        },
        {
            "pattern": r'input\s*\(\s*\)',
            "issue_id": "SEC_006",
            "severity": SeverityLevel.LOW,
            "title": "Unsafe Input Usage",
            "description": "input() in Python 2 evaluates the input",
            "suggestion": "Use raw_input() in Python 2 or ensure Python 3"
        },
        {
            "pattern": r'pickle\.loads?\s*\(',
            "issue_id": "SEC_007",
            "severity": SeverityLevel.CRITICAL,
            "title": "Pickle Deserialization",
            "description": "Pickle can execute arbitrary code during deserialization",
            "suggestion": "Use JSON or other safe serialization formats"
        },
        {
            "pattern": r'(password|secret|key|token)\s*=\s*["\'][^"\']+["\']',
            "issue_id": "SEC_008",
            "severity": SeverityLevel.HIGH,
            "title": "Hardcoded Credentials",
            "description": "Credentials should not be hardcoded",
            "suggestion": "Use environment variables or secure vault"
        },
        {
            "pattern": r'SQL\s*=\s*["\'].*%s.*["\']|["\'].*\+.*["\'].*SELECT|["\'].*\+.*["\'].*INSERT|["\'].*\+.*["\'].*UPDATE|["\'].*\+.*["\'].*DELETE',
            "issue_id": "SEC_009",
            "severity": SeverityLevel.CRITICAL,
            "title": "Potential SQL Injection",
            "description": "String concatenation in SQL queries is vulnerable to SQL injection",
            "suggestion": "Use parameterized queries or ORM"
        },
        {
            "pattern": r'requests\.\w+\(.*verify\s*=\s*False',
            "issue_id": "SEC_010",
            "severity": SeverityLevel.HIGH,
            "title": "SSL Verification Disabled",
            "description": "Disabling SSL verification makes requests vulnerable to MITM attacks",
            "suggestion": "Enable SSL verification (verify=True)"
        }
    ]

    def __init__(self):
        super().__init__("SecurityAudit", AgentType.SECURITY_AUDIT)
        self.compiled_patterns = []

    def _initialize(self) -> None:
        self.compiled_patterns = [
            (p, re.compile(p["pattern"], re.IGNORECASE | re.MULTILINE))
            for p in self.VULNERABILITY_PATTERNS
        ]
        logger.info("SecurityAudit Agent initialized with %d patterns", len(self.compiled_patterns))

    def get_priority(self) -> int:
        return 2

    async def analyze(self, file_path: str, code: str, context: Optional[Dict] = None) -> AnalysisResult:
        result = AnalysisResult(agent_type=self.agent_type)
        result.reasoning_chain.append("Step 1: Load security vulnerability patterns")
        result.reasoning_chain.append("Step 2: Scan code for known vulnerabilities")
        result.reasoning_chain.append("Step 3: Analyze context for security risks")
        result.reasoning_chain.append("Step 4: Prioritize findings by severity")

        lines = code.split('\n')
        
        for pattern_info, compiled_pattern in self.compiled_patterns:
            for line_num, line in enumerate(lines, 1):
                if compiled_pattern.search(line):
                    issue = CodeIssue(
                        issue_id=pattern_info["issue_id"],
                        agent_type=self.agent_type,
                        severity=pattern_info["severity"],
                        title=pattern_info["title"],
                        description=pattern_info["description"],
                        file_path=file_path,
                        line_number=line_num,
                        code_snippet=line.strip(),
                        suggestion=pattern_info["suggestion"],
                        confidence=0.95
                    )
                    result.add_issue(issue)

        self._check_imports(code, file_path, result)
        
        critical_count = len(result.get_critical_issues())
        result.reasoning_chain.append(f"Found {critical_count} critical vulnerabilities")
        result.summary = f"Security scan complete: {len(result.issues)} issues found"
        
        return result

    def _check_imports(self, code: str, file_path: str, result: AnalysisResult) -> None:
        dangerous_imports = {
            'telnetlib': ('SEC_011', SeverityLevel.HIGH, 'Insecure Telnet Protocol', 'Use SSH instead'),
            'ftplib': ('SEC_012', SeverityLevel.MEDIUM, 'Insecure FTP Protocol', 'Use SFTP or FTPS instead'),
        }

        for module, (issue_id, severity, title, suggestion) in dangerous_imports.items():
            if f'import {module}' in code or f'from {module}' in code:
                result.add_issue(CodeIssue(
                    issue_id=issue_id,
                    agent_type=self.agent_type,
                    severity=severity,
                    title=title,
                    description=f"Using insecure module: {module}",
                    file_path=file_path,
                    line_number=0,
                    suggestion=suggestion,
                    confidence=1.0
                ))
