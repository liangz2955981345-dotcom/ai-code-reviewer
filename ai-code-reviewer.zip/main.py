"""CLI interface for AI Code Reviewer"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

from src.agents import (
    CodeParserAgent,
    SecurityAuditAgent,
    PerformanceOptimizerAgent,
    StyleCheckerAgent
)
from src.core.orchestrator import AgentOrchestrator

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


async def analyze_file(file_path: str, output_format: str = "text") -> None:
    """Analyze a single file"""
    path = Path(file_path)
    
    if not path.exists():
        print(f"Error: File '{file_path}' not found")
        sys.exit(1)
    
    code = path.read_text(encoding='utf-8')
    
    agents = [
        CodeParserAgent(),
        SecurityAuditAgent(),
        PerformanceOptimizerAgent(),
        StyleCheckerAgent()
    ]
    
    for agent in agents:
        agent.initialize()
    
    orchestrator = AgentOrchestrator(agents)
    result = await orchestrator.orchestrate(str(path), code)
    
    if output_format == "json":
        output = {
            "file": str(path),
            "total_issues": result.total_issues,
            "execution_time": result.execution_time,
            "summary": result.get_summary(),
            "results": [r.to_dict() for r in result.results],
            "reasoning_chain": [step.to_dict() for step in result.reasoning_chain],
            "recommendations": result.recommendations
        }
        print(json.dumps(output, indent=2))
    elif output_format == "text":
        print(result.to_report())
    else:
        print(f"Error: Unknown output format '{output_format}'")
        sys.exit(1)


async def analyze_directory(dir_path: str, output_format: str = "text") -> None:
    """Analyze all Python files in a directory"""
    path = Path(dir_path)
    
    if not path.is_dir():
        print(f"Error: Directory '{dir_path}' not found")
        sys.exit(1)
    
    python_files = list(path.rglob("*.py"))
    
    if not python_files:
        print(f"No Python files found in '{dir_path}'")
        return
    
    print(f"Found {len(python_files)} Python files to analyze\n")
    
    agents = [
        CodeParserAgent(),
        SecurityAuditAgent(),
        PerformanceOptimizerAgent(),
        StyleCheckerAgent()
    ]
    
    for agent in agents:
        agent.initialize()
    
    orchestrator = AgentOrchestrator(agents)
    
    total_issues = 0
    for py_file in python_files:
        print(f"\n{'='*80}")
        print(f"Analyzing: {py_file}")
        print(f"{'='*80}\n")
        
        code = py_file.read_text(encoding='utf-8')
        result = await orchestrator.orchestrate(str(py_file), code)
        
        if output_format == "text":
            print(result.to_report())
        else:
            output = {
                "file": str(py_file),
                "total_issues": result.total_issues,
                "results": [r.to_dict() for r in result.results]
            }
            print(json.dumps(output, indent=2))
        
        total_issues += result.total_issues
    
    print(f"\n{'='*80}")
    print(f"SUMMARY: Analyzed {len(python_files)} files, found {total_issues} total issues")
    print(f"{'='*80}")


def main():
    parser = argparse.ArgumentParser(
        description="AI Code Reviewer - Multi-Agent Code Review and Optimization Platform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py analyze file.py
  python main.py analyze file.py --format json
  python main.py analyze ./src --recursive
  python main.py demo
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    analyze_parser = subparsers.add_parser('analyze', help='Analyze code file or directory')
    analyze_parser.add_argument('path', help='File or directory path to analyze')
    analyze_parser.add_argument(
        '--format', '-f',
        choices=['text', 'json'],
        default='text',
        help='Output format (default: text)'
    )
    analyze_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )
    
    demo_parser = subparsers.add_parser('demo', help='Run demo analysis')
    demo_parser.add_argument(
        '--format', '-f',
        choices=['text', 'json'],
        default='text',
        help='Output format (default: text)'
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    if args.command == 'analyze':
        setup_logging(args.verbose if hasattr(args, 'verbose') else False)
        path = Path(args.path)
        
        if path.is_file():
            asyncio.run(analyze_file(args.path, args.format))
        elif path.is_dir():
            asyncio.run(analyze_directory(args.path, args.format))
        else:
            print(f"Error: Path '{args.path}' does not exist")
            sys.exit(1)
    
    elif args.command == 'demo':
        setup_logging()
        demo_path = Path(__file__).parent / "examples" / "sample_code.py"
        if demo_path.exists():
            asyncio.run(analyze_file(str(demo_path), args.format))
        else:
            print("Demo file not found. Please run with 'analyze' command on your code.")


if __name__ == "__main__":
    main()
