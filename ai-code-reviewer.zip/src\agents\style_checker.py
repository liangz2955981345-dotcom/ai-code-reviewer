"""Style Checker Agent - Detects code style issues"""

import re
import logging
from typing import Dict, List, Optional

from ..core.agent import BaseAgent, AnalysisResult, CodeIssue, SeverityLevel, AgentType

logger = logging.getLogger(__name__)


class StyleCheckerAgent(BaseAgent):
    """Checks code style and conventions"""

    def __init__(self):
        super().__init__("StyleChecker", AgentType.STYLE_CHECKER)
        self.max_line_length = 120
        self.max_file_length = 1000

    def _initialize(self) -> None:
        logger.info("StyleChecker Agent initialized")

    def get_priority(self) -> int:
        return 4

    async def analyze(self, file_path: str, code: str, context: Optional[Dict] = None) -> AnalysisResult:
        result = AnalysisResult(agent_type=self.agent_type)
        result.reasoning_chain.append("Step 1: Check PEP 8 compliance")
        result.reasoning_chain.append("Step 2: Analyze naming conventions")
        result.reasoning_chain.append("Step 3: Check documentation")
        result.reasoning_chain.append("Step 4: Verify code organization")

        lines = code.split('\n')

        self._check_line_length(lines, file_path, result)
        self._check_file_length(lines, file_path, result)
        self._check_naming_conventions(code, lines, file_path, result)
        self._check_documentation(code, lines, file_path, result)
        self._check_whitespace(lines, file_path, result)
        self._check_magic_numbers(code, lines, file_path, result)

        result.summary = f"Style check complete: {len(result.issues)} issues found"
        return result

    def _check_line_length(self, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        for i, line in enumerate(lines, 1):
            if len(line.rstrip()) > self.max_line_length:
                result.add_issue(CodeIssue(
                    issue_id="STYLE_001",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.LOW,
                    title="Line Too Long",
                    description=f"Line {i} has {len(line.rstrip())} characters (max: {self.max_line_length})",
                    file_path=file_path,
                    line_number=i,
                    suggestion="Break the line into multiple lines"
                ))

    def _check_file_length(self, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        if len(lines) > self.max_file_length:
            result.add_issue(CodeIssue(
                issue_id="STYLE_002",
                agent_type=self.agent_type,
                severity=SeverityLevel.MEDIUM,
                title="File Too Long",
                description=f"File has {len(lines)} lines (max: {self.max_file_length})",
                file_path=file_path,
                line_number=0,
                suggestion="Split into smaller modules"
            ))

    def _check_naming_conventions(self, code: str, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        func_pattern = re.compile(r'def\s+([a-zA-Z_]\w*)\s*\(')
        class_pattern = re.compile(r'class\s+([a-zA-Z_]\w*)\s*[\(:]')
        
        for i, line in enumerate(lines, 1):
            func_match = func_pattern.search(line)
            if func_match:
                func_name = func_match.group(1)
                if not func_name.startswith('_') and func_name[0].isupper():
                    result.add_issue(CodeIssue(
                        issue_id="STYLE_003",
                        agent_type=self.agent_type,
                        severity=SeverityLevel.LOW,
                        title="Function Naming Convention",
                        description=f"Function '{func_name}' should be snake_case",
                        file_path=file_path,
                        line_number=i,
                        suggestion="Use snake_case for function names"
                    ))

            class_match = class_pattern.search(line)
            if class_match:
                class_name = class_match.group(1)
                if '_' in class_name:
                    result.add_issue(CodeIssue(
                        issue_id="STYLE_004",
                        agent_type=self.agent_type,
                        severity=SeverityLevel.LOW,
                        title="Class Naming Convention",
                        description=f"Class '{class_name}' should use PascalCase without underscores",
                        file_path=file_path,
                        line_number=i,
                        suggestion="Use PascalCase for class names"
                    ))

    def _check_documentation(self, code: str, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        import ast
        
        try:
            tree = ast.parse(code)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    if (node.body and 
                        isinstance(node.body[0], ast.Expr) and 
                        isinstance(node.body[0].value, (ast.Str, ast.Constant))):
                        continue
                    
                    node_type = "function" if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) else "class"
                    if not node.name.startswith('_'):
                        result.add_issue(CodeIssue(
                            issue_id="STYLE_005",
                            agent_type=self.agent_type,
                            severity=SeverityLevel.INFO,
                            title="Missing Documentation",
                            description=f"{node_type.capitalize()} '{node.name}' lacks docstring",
                            file_path=file_path,
                            line_number=node.lineno,
                            suggestion=f"Add a docstring to {node_type} '{node.name}'"
                        ))
        except:
            pass

    def _check_whitespace(self, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        for i, line in enumerate(lines, 1):
            if line.endswith((' ', '\t')):
                result.add_issue(CodeIssue(
                    issue_id="STYLE_006",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.INFO,
                    title="Trailing Whitespace",
                    description="Line has trailing whitespace",
                    file_path=file_path,
                    line_number=i,
                    suggestion="Remove trailing whitespace"
                ))

    def _check_magic_numbers(self, code: str, lines: List[str], file_path: str, result: AnalysisResult) -> None:
        magic_pattern = re.compile(r'(?<!["\w])(\d{2,})(?!["\w])')
        
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith('#') or stripped.startswith('"""') or stripped.startswith("'''"):
                continue
            
            matches = magic_pattern.findall(line)
            for match in matches:
                num = int(match)
                if num not in [0, 1, 2]:
                    result.add_issue(CodeIssue(
                        issue_id="STYLE_007",
                        agent_type=self.agent_type,
                        severity=SeverityLevel.INFO,
                        title="Magic Number",
                        description=f"Magic number {num} found",
                        file_path=file_path,
                        line_number=i,
                        suggestion="Define as a named constant"
                    ))
                    break
