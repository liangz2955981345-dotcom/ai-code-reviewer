"""Sample code with intentional issues for demonstration"""

import os
import pickle
import subprocess

password = "super_secret_123"
SECRET_KEY = "my-secret-key"

def process_data(data_list):
    result = []
    for i in range(len(data_list)):
        result.append(data_list[i] * 2)
    return result

def complex_function(a, b, c, d, e, f, g):
    if a > 0:
        if b > 0:
            if c > 0:
                if d > 0:
                    if e > 0:
                        return a + b + c + d + e
    return 0

class utility_class:
    def HelperFunction(self):
        pass
    
    def AnotherHelper(self):
        pass
    
    def ThirdHelper(self):
        pass

def execute_command(cmd):
    os.system(cmd)
    exec(cmd)
    result = eval("1 + 1")
    return result

def load_data(filename):
    with open(filename, 'rb') as f:
        data = pickle.load(f)
    return data

def build_query(user_input):
    SQL = "SELECT * FROM users WHERE name = '" + user_input + "'"
    return SQL

message = "Hello " + "World " + "from " + "Python " + "Code " + "Reviewer " + "System " + "Here"

CONFIG_VALUE = 42
ANOTHER_VALUE = 100
