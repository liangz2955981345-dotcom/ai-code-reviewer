"""AI Code Reviewer - Multi-Agent Code Review and Optimization Platform"""

__version__ = "1.0.0"
__author__ = "AI Code Reviewer Team"
