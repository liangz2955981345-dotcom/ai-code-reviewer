"""Core agent framework with base classes and interfaces"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class SeverityLevel(Enum):
    """Issue severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AgentType(Enum):
    """Available agent types"""
    CODE_PARSER = "code_parser"
    SECURITY_AUDIT = "security_audit"
    PERFORMANCE_OPTIMIZER = "performance_optimizer"
    STYLE_CHECKER = "style_checker"


@dataclass
class CodeIssue:
    """Represents a code issue found during analysis"""
    issue_id: str
    agent_type: AgentType
    severity: SeverityLevel
    title: str
    description: str
    file_path: str
    line_number: int
    column: int = 0
    code_snippet: str = ""
    suggestion: str = ""
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "agent_type": self.agent_type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column": self.column,
            "code_snippet": self.code_snippet,
            "suggestion": self.suggestion,
            "confidence": self.confidence,
            "metadata": self.metadata
        }


@dataclass
class AnalysisResult:
    """Complete analysis result from an agent"""
    agent_type: AgentType
    issues: List[CodeIssue] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)
    summary: str = ""
    reasoning_chain: List[str] = field(default_factory=list)

    def add_issue(self, issue: CodeIssue) -> None:
        self.issues.append(issue)
        logger.debug(f"Added issue: {issue.title} ({issue.severity.value})")

    def get_critical_issues(self) -> List[CodeIssue]:
        return [i for i in self.issues if i.severity == SeverityLevel.CRITICAL]

    def get_high_issues(self) -> List[CodeIssue]:
        return [i for i in self.issues if i.severity == SeverityLevel.HIGH]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_type": self.agent_type.value,
            "issues": [i.to_dict() for i in self.issues],
            "metrics": self.metrics,
            "summary": self.summary,
            "reasoning_chain": self.reasoning_chain
        }


class BaseAgent(ABC):
    """Abstract base class for all code review agents"""

    def __init__(self, name: str, agent_type: AgentType):
        self.name = name
        self.agent_type = agent_type
        self.is_initialized = False

    def initialize(self) -> None:
        """Initialize agent resources"""
        logger.info(f"Initializing {self.name} agent...")
        self._initialize()
        self.is_initialized = True

    @abstractmethod
    def _initialize(self) -> None:
        """Agent-specific initialization"""
        pass

    @abstractmethod
    async def analyze(self, file_path: str, code: str, context: Optional[Dict] = None) -> AnalysisResult:
        """Analyze code and return results"""
        pass

    def can_handle(self, file_path: str) -> bool:
        """Check if this agent can handle the given file"""
        return True

    def get_priority(self) -> int:
        """Return execution priority (lower = higher priority)"""
        return 0
