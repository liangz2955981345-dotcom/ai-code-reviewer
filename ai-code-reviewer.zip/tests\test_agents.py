"""Tests for AI Code Reviewer agents"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


SAMPLE_CODE = '''
def hello():
    print("Hello World")

def process_data(data_list):
    result = []
    for i in range(len(data_list)):
        result.append(data_list[i])
    return result

password = "secret123"

import os
def run_cmd(cmd):
    os.system(cmd)
'''


def run_test():
    import asyncio
    from src.agents import (
        CodeParserAgent,
        SecurityAuditAgent,
        PerformanceOptimizerAgent,
        StyleCheckerAgent
    )
    from src.core.orchestrator import AgentOrchestrator

    print("=" * 60)
    print("Testing AI Code Reviewer Agents")
    print("=" * 60)
    
    agents = [
        CodeParserAgent(),
        SecurityAuditAgent(),
        PerformanceOptimizerAgent(),
        StyleCheckerAgent()
    ]
    
    for agent in agents:
        print(f"\nInitializing {agent.name} Agent...")
        agent.initialize()
        print(f"  Status: {'Ready' if agent.is_initialized else 'Failed'}")
    
    async def test():
        orchestrator = AgentOrchestrator(agents)
        result = await orchestrator.orchestrate("test_code.py", SAMPLE_CODE)
        return result
    
    result = asyncio.run(test())
    
    print(f"\n{'='*60}")
    print("TEST RESULTS")
    print(f"{'='*60}")
    print(f"Total Issues Found: {result.total_issues}")
    print(f"Execution Time: {result.execution_time:.3f}s")
    print(f"Reasoning Steps: {len(result.reasoning_chain)}")
    
    for agent_result in result.results:
        print(f"\n[{agent_result.agent_type.value.upper()}]")
        print(f"  Issues: {len(agent_result.issues)}")
        print(f"  Summary: {agent_result.summary}")
    
    print(f"\n{'='*60}")
    print("RECOMMENDATIONS")
    print(f"{'='*60}")
    for rec in result.recommendations:
        print(f"  - {rec}")
    
    print(f"\n{'='*60}")
    print("ALL TESTS PASSED!")
    print(f"{'='*60}")


if __name__ == "__main__":
    run_test()
