"""Code Parser Agent - Analyzes code structure and AST"""

import ast
import logging
from typing import Dict, Optional

from ..core.agent import BaseAgent, AnalysisResult, CodeIssue, SeverityLevel, AgentType

logger = logging.getLogger(__name__)


class CodeParserAgent(BaseAgent):
    """Parses code and analyzes its structure"""

    def __init__(self):
        super().__init__("CodeParser", AgentType.CODE_PARSER)
        self.metrics = {}

    def _initialize(self) -> None:
        logger.info("CodeParser Agent initialized")

    def can_handle(self, file_path: str) -> bool:
        return file_path.endswith('.py')

    def get_priority(self) -> int:
        return 1

    async def analyze(self, file_path: str, code: str, context: Optional[Dict] = None) -> AnalysisResult:
        result = AnalysisResult(agent_type=self.agent_type)
        result.reasoning_chain.append("Step 1: Parse code into AST")
        result.reasoning_chain.append("Step 2: Analyze code structure")
        result.reasoning_chain.append("Step 3: Calculate metrics")

        try:
            tree = ast.parse(code)
            result.reasoning_chain.append("Successfully parsed AST")
        except SyntaxError as e:
            issue = CodeIssue(
                issue_id="SYNTAX_001",
                agent_type=self.agent_type,
                severity=SeverityLevel.CRITICAL,
                title="Syntax Error",
                description=f"Code has syntax error: {str(e)}",
                file_path=file_path,
                line_number=e.lineno or 0,
                column=e.offset or 0
            )
            result.add_issue(issue)
            result.summary = "Code contains syntax errors"
            return result

        self._analyze_functions(tree, code, file_path, result)
        self._analyze_classes(tree, code, file_path, result)
        self._analyze_complexity(tree, code, file_path, result)
        self._calculate_metrics(tree, code, result)

        result.summary = f"Analyzed {self.metrics.get('function_count', 0)} functions, {self.metrics.get('class_count', 0)} classes"
        result.metrics.update(self.metrics)
        
        return result

    def _analyze_functions(self, tree: ast.AST, code: str, file_path: str, result: AnalysisResult) -> None:
        functions = [node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
        self.metrics['function_count'] = len(functions)

        for func in functions:
            if len(func.args.args) > 5:
                result.add_issue(CodeIssue(
                    issue_id="FUNC_001",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.MEDIUM,
                    title="Too Many Parameters",
                    description=f"Function '{func.name}' has {len(func.args.args)} parameters (recommended: <= 5)",
                    file_path=file_path,
                    line_number=func.lineno,
                    suggestion="Consider using a configuration object or dataclass"
                ))

    def _analyze_classes(self, tree: ast.AST, code: str, file_path: str, result: AnalysisResult) -> None:
        classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
        self.metrics['class_count'] = len(classes)

        for cls in classes:
            methods = [n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if len(methods) > 10:
                result.add_issue(CodeIssue(
                    issue_id="CLASS_001",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.MEDIUM,
                    title="God Class Detected",
                    description=f"Class '{cls.name}' has {len(methods)} methods (recommended: <= 10)",
                    file_path=file_path,
                    line_number=cls.lineno,
                    suggestion="Consider splitting into smaller, focused classes"
                ))

    def _analyze_complexity(self, tree: ast.AST, code: str, file_path: str, result: AnalysisResult) -> None:
        for func in [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
            complexity = 1
            for node in ast.walk(func):
                if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                    complexity += 1
                elif isinstance(node, ast.BoolOp):
                    complexity += len(node.values) - 1

            self.metrics[f'{func.name}_complexity'] = complexity

            if complexity > 10:
                result.add_issue(CodeIssue(
                    issue_id="COMP_001",
                    agent_type=self.agent_type,
                    severity=SeverityLevel.HIGH,
                    title="High Cyclomatic Complexity",
                    description=f"Function '{func.name}' has complexity of {complexity} (recommended: <= 10)",
                    file_path=file_path,
                    line_number=func.lineno,
                    suggestion="Refactor into smaller functions"
                ))

    def _calculate_metrics(self, tree: ast.AST, code: str, result: AnalysisResult) -> None:
        lines = code.split('\n')
        self.metrics['total_lines'] = len(lines)
        self.metrics['non_empty_lines'] = len([l for l in lines if l.strip()])
        self.metrics['comment_lines'] = len([l for l in lines if l.strip().startswith('#')])
